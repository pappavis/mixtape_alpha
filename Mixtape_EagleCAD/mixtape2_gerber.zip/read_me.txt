Files in this archive:

mixtape2.gbl		bottom layer gerber file
mixtape2.gko		keep out layer (ie board border) gerber
mixtape2.gtl		top layer gerber file
mixtape2.gbs		bottom layer solder mask
mixtape2.gts		top layer solder mask
mixtape2.gto		top layer silkscreen
mixtape2.gbo		bottom layer silkscreen
mixtape2.dri		NC Drill report file
mixtape2.txt		Excellon drill file
mixtape2.gtp		top layer paste mask
read_me.txt			This file

Board comments:

none